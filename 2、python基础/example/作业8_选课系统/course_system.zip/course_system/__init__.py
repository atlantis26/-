# coding:utf-8
from conf.settings import *


init_logging()

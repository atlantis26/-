from core.main import console
from conf.settings import init_logging

init_logging()

if __name__ == "__main__":
    console()

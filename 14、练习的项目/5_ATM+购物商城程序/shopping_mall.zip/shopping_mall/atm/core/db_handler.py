# coding:utf-8


def create_db_session():
    """连接数据库，生成db_session"""
    pass


def save_account():
    """将账户信息写入数据库"""
    pass


def load_account():
    """将账户信息从数据库查询出"""
    pass


def account_is_exists():
    """检查账户是否存在"""
    pass


def save_account_flow():
    """将账户消费流水信息写入数据库"""
    pass


def query_account_flow():
    """将账户消费流水信息从数据库查询出"""
    pass


def close_db_session():
    """断开数据库连接"""
    pass

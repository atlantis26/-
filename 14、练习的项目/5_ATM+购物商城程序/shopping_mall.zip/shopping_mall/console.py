# coding:utf-8

from mall.core.main import console


if __name__ == "__main__":
    console()

# coding:utf-8

from mall.conf.settings import *


# 初始化日志模块
init_logging()
